class RewardSystem:
    def __init__(self, maze_size=5):
        # 根据迷宫大小调整奖励值
        if maze_size <= 5:  # 简单迷宫
            self.rewards = {
                'exit': 150,      # 到达出口（适当提高）
                'trap': -60,      # 掉入陷阱（适当加重）
                'wall': -8,       # 撞墙（适当减轻）
                'step': -2,       # 每走一步（适当加重）
                'invalid': -15    # 无效移动（适当减轻）
            }
        else:  # 复杂迷宫
            self.rewards = {
                'exit': 300,      # 到达出口（大幅提高）
                'trap': -120,     # 掉入陷阱（大幅加重）
                'wall': -10,      # 撞墙（适当减轻）
                'step': -3,       # 每走一步（适当加重）
                'invalid': -20    # 无效移动（适当减轻）
            }
        
    def get_reward(self, action_result):
        """
        根据动作结果返回相应的奖励
        action_result: 字典，包含以下键：
            - 'hit_wall': 是否撞墙
            - 'in_trap': 是否在陷阱中
            - 'reached_exit': 是否到达出口
            - 'valid_move': 是否是有效移动
        """
        reward = 0
        
        if action_result['reached_exit']:
            reward += self.rewards['exit']
        if action_result['in_trap']:
            reward += self.rewards['trap']
        if action_result['hit_wall']:
            reward += self.rewards['wall']
        if not action_result['valid_move']:
            reward += self.rewards['invalid']
        else:
            reward += self.rewards['step']
            
        return reward 