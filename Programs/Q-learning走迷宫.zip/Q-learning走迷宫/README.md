# Q-learning 迷宫求解

这是一个使用 Q-learning 算法解决迷宫问题的项目，包含 3D 可视化功能。

## 项目结构

- `maze.py`: 迷宫环境类
- `agent.py`: Q-learning 智能体
- `rewards.py`: 奖励系统
- `visualizer.py`: 3D 可视化
- `main.py`: 主程序

## 功能特点

1. 迷宫环境包含：
   - 墙体（灰色）
   - 陷阱（红色）
   - 出口（绿色）
   - 智能体（蓝色）

2. Q-learning 算法特点：
   - ε-贪婪策略
   - 可调节的学习率和折扣因子
   - 自定义奖励系统

3. 3D 可视化功能：
   - 实时显示训练过程
   - 支持视角旋转和俯仰
   - 光照效果
   - 多线程渲染

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

1. 运行主程序：
```bash
python main.py
```

2. 控制视角：
   - 左右箭头键：旋转视角
   - 上下箭头键：调整俯仰角度

## 参数调整

可以在以下文件中调整参数：

1. `maze.py`:
   - 迷宫大小
   - 墙体、陷阱、出口位置

2. `agent.py`:
   - 学习率 (learning_rate)
   - 折扣因子 (discount_factor)
   - 探索率 (exploration_rate)

3. `visualizer.py`:
   - 窗口大小
   - 格子大小
   - 渲染延迟

4. `rewards.py`:
   - 各种情况的奖励值

## 注意事项

1. 确保已安装所有依赖
2. 如果遇到 OpenGL 错误，请检查显卡驱动是否最新
3. 可视化窗口可以通过点击关闭按钮或按 ESC 键退出 