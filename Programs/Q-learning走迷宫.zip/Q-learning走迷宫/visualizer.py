import pygame
import numpy as np
from maze import Maze

class MazeVisualizer:
    def __init__(self, maze, cell_size=80):
        self.maze = maze
        self.cell_size = cell_size
        self.window_width = maze.width * cell_size
        self.window_height = maze.height * cell_size
        
        # 初始化Pygame
        pygame.init()
        # 设置窗口显示属性，确保显示在前面
        self.screen = pygame.display.set_mode(
            (self.window_width, self.window_height),
            pygame.HWSURFACE | pygame.DOUBLEBUF | pygame.SHOWN  # 添加标志确保窗口显示在前面
        )
        pygame.display.set_caption("Q-learning Maze")
        
        # 把窗口提到前面
        pygame.display.set_allow_screensaver(False)  # 禁用屏保
        
        # 定义颜色
        self.colors = {
            'wall': (100, 100, 100),    # 灰色
            'trap': (255, 0, 0),        # 红色
            'exit': (0, 255, 0),        # 绿色
            'agent': (0, 0, 255),       # 蓝色
            'floor': (200, 200, 200),    # 浅灰色
            'background': (255, 255, 255) # 白色
        }
        
    def draw_cell(self, x, y, color):
        """绘制一个格子"""
        rect = pygame.Rect(
            x * self.cell_size,
            y * self.cell_size,
            self.cell_size,
            self.cell_size
        )
        pygame.draw.rect(self.screen, color, rect)
        pygame.draw.rect(self.screen, (0, 0, 0), rect, 1)  # 绘制边框
        
    def draw_maze(self):
        """绘制迷宫"""
        # 清空屏幕
        self.screen.fill(self.colors['background'])
        
        # 绘制地板
        for y in range(self.maze.height):
            for x in range(self.maze.width):
                self.draw_cell(x, y, self.colors['floor'])
        
        # 绘制墙体
        for x, y in self.maze.wall_positions:
            self.draw_cell(x, y, self.colors['wall'])
            
        # 绘制陷阱
        for x, y in self.maze.trap_positions:
            self.draw_cell(x, y, self.colors['trap'])
            
        # 绘制出口
        if self.maze.exit_position:
            x, y = self.maze.exit_position
            self.draw_cell(x, y, self.colors['exit'])
            
        # 绘制智能体
        if self.maze.agent_position:
            x, y = self.maze.agent_position
            self.draw_cell(x, y, self.colors['agent'])
            
    def handle_events(self):
        """处理用户输入"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
        return True
        
    def render(self):
        """渲染场景"""
        self.draw_maze()
        pygame.display.flip()
        pygame.time.wait(10)
        
    def run(self):
        """运行可视化"""
        running = True
        while running:
            running = self.handle_events()
            self.render()
        pygame.quit() 