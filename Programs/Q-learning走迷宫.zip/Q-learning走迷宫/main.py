from maze import Maze, create_simple_maze, create_complex_maze, create_spiral_maze
from agent import QLearningAgent
from rewards import RewardSystem
from visualizer import MazeVisualizer
import threading
import time
import matplotlib.pyplot as plt
import os
import datetime

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def get_maze_choice():
    """获取用户选择的地图"""
    while True:
        print("\n请选择迷宫难度：")
        print("1. 简单迷宫 (5x5)")
        print("2. 复杂迷宫 (8x8)")
        print("3. 螺旋迷宫 (6x6)")
        choice = input("请输入选项 (1/2/3): ")
        
        if choice == '1':
            return create_simple_maze(), 3000  # 简单迷宫训练3000轮
        elif choice == '2':
            return create_complex_maze(), 5000  # 复杂迷宫训练5000轮
        elif choice == '3':
            return create_spiral_maze(), 4000  # 螺旋迷宫训练4000轮
        else:
            print("无效的选项，请重新选择")

def plot_training_stats(episode_rewards, success_rates, avg_steps, exploration_rates, save_dir):
    """绘制训练统计图表并保存到指定目录"""
    plt.figure(figsize=(15, 10))
    
    # 创建子图
    plt.subplot(2, 2, 1)
    plt.plot(episode_rewards)
    plt.title('每轮平均奖励')
    plt.xlabel('轮数')
    plt.ylabel('奖励')
    
    plt.subplot(2, 2, 2)
    plt.plot(success_rates)
    plt.title('成功率')
    plt.xlabel('轮数')
    plt.ylabel('成功率 (%)')
    
    plt.subplot(2, 2, 3)
    plt.plot(avg_steps)
    plt.title('平均步数')
    plt.xlabel('轮数')
    plt.ylabel('步数')
    
    plt.subplot(2, 2, 4)
    plt.plot(exploration_rates)
    plt.title('探索率变化')
    plt.xlabel('轮数')
    plt.ylabel('探索率')
    
    plt.tight_layout()
    
    # 保存图表
    plt.savefig(os.path.join(save_dir, 'training_stats.png'))
    plt.close()

def train_agent(maze, episodes=2000, visualize=False):
    """训练智能体"""
    # 创建奖励系统
    reward_system = RewardSystem(maze_size=maze.height)
    agent = QLearningAgent(maze, reward_system)
    
    # 如果需要可视化，启动可视化线程
    if visualize:
        visualizer = MazeVisualizer(maze)
        visualizer_thread = threading.Thread(target=visualizer.run)
        visualizer_thread.daemon = True
        visualizer_thread.start()
        
        # 设置pygame窗口位置
        os.environ['SDL_VIDEO_WINDOW_POS'] = "100,100"  # 设置窗口位置
        os.environ['SDL_VIDEO_CENTERED'] = '1'  # 确保窗口居中显示
    
    # 记录训练统计信息
    success_count = 0
    total_steps = 0
    best_reward = float('-inf')
    
    # 用于绘图的统计数据
    episode_rewards = []
    success_rates = []
    avg_steps_list = []
    exploration_rates = []
    
    print(f"\n开始训练，共{episodes}轮...")
    for episode in range(episodes):
        state = maze.reset()
        total_reward = 0
        done = False
        steps = 0
        
        while not done:
            # 选择动作
            action = agent.choose_action(state)
            
            # 执行动作
            action_result = agent.take_action(action)
            reward = reward_system.get_reward(action_result)
            next_state = maze.get_state()
            
            # 更新Q值
            agent.update_q_value(state, action, reward, next_state)
            
            total_reward += reward
            state = next_state
            steps += 1
            
            # 检查是否结束
            if action_result['reached_exit']:
                done = True
                success_count += 1
            elif action_result['in_trap']:
                done = True
                
            # 如果可视化，添加短暂延迟以便观察
            if visualize:
                time.sleep(0.1)
        
        total_steps += steps
        best_reward = max(best_reward, total_reward)
        
        # 记录统计数据
        episode_rewards.append(total_reward)
        current_success_rate = (success_count / (episode + 1)) * 100
        success_rates.append(current_success_rate)
        avg_steps_list.append(total_steps / (episode + 1))
        exploration_rates.append(agent.exploration_rate)
        
        # 每100轮打印一次训练信息
        if (episode + 1) % 100 == 0:
            success_rate = (success_count / 100) * 100
            avg_steps = total_steps / 100
            print(f"\nEpisode {episode + 1}/{episodes} 训练统计:")
            print(f"最近100轮成功率: {success_rate:.2f}%")
            print(f"最近100轮平均步数: {avg_steps:.2f}")
            print(f"最近100轮最高奖励: {best_reward}")
            print(f"探索率: {agent.exploration_rate:.4f}")
            
            # 重置统计信息
            success_count = 0
            total_steps = 0
            best_reward = float('-inf')
            
        # 每10轮打印一个进度点
        elif (episode + 1) % 10 == 0:
            print(".", end="", flush=True)
            
    print("\n训练完成！")
    
    # 创建输出目录
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join("output", timestamp)
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存训练统计图表
    plot_training_stats(episode_rewards, success_rates, avg_steps_list, exploration_rates, output_dir)
    print(f"训练统计图表已保存至 '{output_dir}'")
    
    return agent, maze

def test_agent(agent, maze, visualize=False):
    """测试训练好的智能体"""
    state = maze.reset()
    done = False
    steps = 0
    
    # 如果需要可视化，启动可视化线程
    if visualize:
        visualizer = MazeVisualizer(maze)
        visualizer_thread = threading.Thread(target=visualizer.run)
        visualizer_thread.daemon = True
        visualizer_thread.start()
    
    print("\n开始测试训练好的智能体:")
    while not done and steps < 100:
        action = agent.choose_action(state)
        action_result = agent.take_action(action)
        state = maze.get_state()
        steps += 1
        
        print(f"Step {steps}: Position {state}, Action: {action}")
        
        if action_result['reached_exit']:
            print("成功到达出口!")
            done = True
        elif action_result['in_trap']:
            print("掉入陷阱!")
            done = True
            
        # 如果可视化，添加短暂延迟以便观察
        if visualize:
            time.sleep(0.5)
            
    if not done:
        print("在100步内未能到达出口")

if __name__ == "__main__":
    # 确保output目录存在
    os.makedirs("output", exist_ok=True)
    
    # 获取用户选择的地图和对应的训练轮数
    maze, episodes = get_maze_choice()
    
    # 训练智能体（不带可视化，因为会干扰训练过程）
    agent, maze = train_agent(maze, episodes=episodes, visualize=False)
    
    # 测试智能体（带可视化）
    test_agent(agent, maze, visualize=True) 